import { Expose } from 'class-transformer';

export class Worker {
    @Expose()
    employee_id: string;

    @Expose()
    name: string;
}