import { Injectable } from '@nestjs/common';
import * as fs from 'fs';
import { Worker } from './worker';

@Injectable()
export class WorkerService {
    private readonly jsonFile: string;

    constructor() {
        this.jsonFile = fs.readFileSync('/home/debian-client/API/project-name/worker.json', 'utf8');
    }

    async getWorker(): Promise<string> {
        return this.jsonFile;
    }


    getWorkerById(id: string): string{
        const workers = JSON.parse(this.jsonFile);
        const worker = workers.find((w: any) => w.employee_id === id);
        return worker ? JSON.stringify(worker) : 'Worker not found';
    }
}
