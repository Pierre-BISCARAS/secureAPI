import { Controller, Get, Param, Req, UseGuards } from '@nestjs/common';
import { WorkerService } from './worker.service';
import { AuthGuard } from 'src/guard/auth.guard';


@Controller('worker')
@UseGuards(AuthGuard)
export class WorkerController {
    constructor(private readonly workerService: WorkerService) {}

    @Get()
    async getWorker(@Req() request: Request): Promise<string> {
        console.log(request)
        return this.workerService.getWorker();
    }

    @Get(":id")
    getWorkerId(@Param('id') id: string): string {
          return this.workerService.getWorkerById(id);
    }
}
