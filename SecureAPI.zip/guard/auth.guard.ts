import { CanActivate, ExecutionContext, Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { Request } from 'express';
import axios from 'axios';
import { Observable } from 'rxjs';

@Injectable()
export class AuthGuard implements CanActivate {
  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    const request = context.switchToHttp().getRequest<Request>();
    const authHeader = request.headers['authorization'];

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new HttpException('Accès refusé: Aucun token fourni', HttpStatus.UNAUTHORIZED);
    }

    const token = authHeader.slice(7);

    return validateToken(token);
  }
}

async function validateToken(token: string): Promise<boolean> {
  const response = await axios.get(`http://localhost:4500/introspect?token=${encodeURIComponent(token)}`);
  const data = response.data;

  if (data.success && data.data && data.data.name === 'Pierre') {
    return true;
  } else {
    throw new HttpException('Accès refusé', HttpStatus.FORBIDDEN);
  }
}
